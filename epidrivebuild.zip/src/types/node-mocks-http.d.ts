declare module 'node-mocks-http' {
    export function createRequest(): any;
    export function createResponse(): any;
  }
  