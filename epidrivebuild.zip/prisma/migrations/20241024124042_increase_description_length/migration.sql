-- AlterTable
ALTER TABLE `Categorie` MODIFY `description` TEXT NULL;
